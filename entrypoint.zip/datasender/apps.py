from django.apps import AppConfig


class DatasenderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'datasender'
